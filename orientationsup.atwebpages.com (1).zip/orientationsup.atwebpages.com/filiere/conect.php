<?php
    $connection = mysqli_connect('fdb33.awardspace.net','4146023_sup','Orientation123','4146023_sup');
    
?>