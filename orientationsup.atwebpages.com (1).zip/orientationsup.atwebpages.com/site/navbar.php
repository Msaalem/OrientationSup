
    <style>.ie-panel{display: none;background: #212121;padding: 10px 0;box-shadow: 3px 3px 5px 0 rgba(0,0,0,.3);clear: both;text-align:center;position: relative;z-index: 1;} html.ie-10 .ie-panel, html.lt-ie-10 .ie-panel {display: block;}
        .p
      {
        color:rgb(20, 50, 185);
        font-size: 140px;
        font-weight: 100;
        font-family: Rock Salt;
      }
      .p2{
        font-size: 120px;
      }
    </style>
     <style>
         nav ul ul{
  position: absolute;
  opacity: 0;
  visibility: hidden; 
} 
.button-4{
   border: none;
   background: none;
   color:aliceblue;
   padding: auto;
   font-size: 20px;
}
nav ul li:hover > ul{
  top: 60px;
  opacity: 1;
  visibility: visible;
  transition: .3s linear;
  padding: 5px;

}
    </style>

    <div class="ie-panel"><a href="http://windows.microsoft.com/en-US/internet-explorer/"><img src="../site/images/ie8-panel/warning_bar_0000_us.jpg" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today."></a></div>
    <div class="preloader">
      <div class="preloader-body">
        <div class="cssload-container">
          <div class="cssload-speeding-wheel"></div>
        </div>
        <p>Loading...</p>
      </div>
    </div>
    <div class="page">
      <header class="section page-header">
        <!--RD Navbar-->
        <div class="rd-navbar-wrap">
          <nav class="rd-navbar rd-navbar-classic" data-layout="rd-navbar-fixed" data-sm-layout="rd-navbar-fixed" data-md-layout="rd-navbar-fixed" data-md-device-layout="rd-navbar-fixed" data-lg-layout="rd-navbar-static" data-lg-device-layout="rd-navbar-static" data-xl-layout="rd-navbar-static" data-xl-device-layout="rd-navbar-static" data-lg-stick-up-offset="46px" data-xl-stick-up-offset="46px" data-xxl-stick-up-offset="46px" data-lg-stick-up="true" data-xl-stick-up="true" data-xxl-stick-up="true">
            <div class="rd-navbar-collapse-toggle rd-navbar-fixed-element-1" data-rd-navbar-toggle=".rd-navbar-collapse"><span></span></div>
            <div class="rd-navbar-aside-outer rd-navbar-collapse bg-gray-dark">
              
            </div>
            <div class="rd-navbar-main-outer">
              <div class="rd-navbar-main">
                <!--RD Navbar Panel-->
                <div class="rd-navbar-panel">
                  <!--RD Navbar Toggle-->
                  <button class="rd-navbar-toggle" data-rd-navbar-toggle=".rd-navbar-nav-wrap"><span></span></button>
                  <!--RD Navbar Brand-->
                  <div class="rd-navbar-brand">
                    <!--Brand--><a class="brand" href="../index.php"><img class="brand-logo-dark" src="images/logo-default-200x34.png" alt="" width="100" height="17"/><img class="brand-logo-light" src="images/logo-inverse-200x34.png" alt="" width="100" height="17"/></a>
                  </div>
                </div>
                <div class="rd-navbar-main-element">
                  <div class="rd-navbar-nav-wrap">
                    <ul class="rd-navbar-nav">
                      <li class="rd-nav-item"><a class="rd-nav-link" href="../index.php">Home</a>
                      </li>
                      <li class="rd-nav-item"><a class="rd-nav-link" href="login.php">login</a>
                      </li>
                      <li class="rd-nav-item active"><a class="rd-nav-link" href="propos.php">À propos</a>
                      </li>
                      <li class="rd-nav-item"><a class="rd-nav-link" href="contacts.php">Contacts</a>
                      </li>
                      <li class="rd-nav-item"><a class="rd-nav-link" href="#">etablissement</a>
                      <i class="fas fa-caret-down"></i>
                      <ul class="rd-navbar-nav">
                      <?php
                                        $conn=mysqli_connect('fdb33.awardspace.net','4146023_sup','Orientation123','4146023_sup');
                                        $query="select * from etablissement";
                                        $result=mysqli_query($conn,$query);
                                        $_SESSION["bool"]=0;
                                        echo "<form action='' method='POST'>";
                                        while($row=mysqli_fetch_assoc($result)){
                                        $nom=$row['nom']; 
                                        echo "<li><a class='rd-nav-link' href='#'><input type='submit' value='$nom' name='submi'  class='button-4' role='button'></a></li>";
                                        // echo "<li><a href='bb.php' class='smoothScroll' onclick='f()'>$nom</a></li>";
                                        // Header('Location: login.php');
                                        }
                                        echo "<li><a class='rd-nav-link' href='#'><input type='submit' value='nouveau' name='submi'  class='button-4' role='button'></a></li>";
                                        echo "</form>";
                                        if(isset($_POST['submi'])){
                                             if($_POST['submi']=='nouveau'){ $_SESSION['x']='';}
                                             else{$_SESSION['x']=$_POST['submi'];}
                                             
                                             echo "<script>window.location.href=\"../filiere/index.php\"</script>";
                                              
                                         }
                                         
                                        ?>
                                        </ul>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </nav>
        </div>
      </header>
      <section class="section section-intro context-dark">
        <div class="intro-bg" style="background: url(images/intro-bg-2.jpg) no-repeat;background-size:cover;background-position: top center;"></div>
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-xl-8 text-center">
              <h1 class="font-weight-bold wow fadeInLeft">À propos</h1>
              <p class="intro-description wow fadeInRight">Lots of Customization Options</p>
            </div>
          </div>
        </div>
      </section>
      <!--Base À propos -->
      
      
    
    <div class="snackbars" id="form-output-global"></div>
    <script src="../site/js/core.min.js"></script>
    <script src="../site/js/script.js"></script>
    