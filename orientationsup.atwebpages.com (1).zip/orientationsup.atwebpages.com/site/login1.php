
                   <?php
   error_reporting(0);
   ini_set('display_errors', 0);
                         $conn = mysqli_connect('fdb33.awardspace.net','4146023_sup','Orientation123','4146023_sup');
                         echo "<script>window.location.href='../filiere/insertion_choix.php'</script>";
                         function test($a)
                         {
                             $a = htmlspecialchars($a);
                             $a = trim($a);
                             return $a;
                         }
                         if (isset($_POST['submit'])) {
                             
                             if (!empty($_POST['matricule']) & !empty($_POST['code1'])) {
                                 $matricule = test($_POST['matricule']);
                                 $code = test($_POST['code1']);
                                 
                                 $req = "select * from utilisateur where matricule=$matricule and code=$code;";
                                 
                                 
                                 $res = mysqli_query($conn, $req);
                                 if (mysqli_num_rows($res) != 0) {
                                     $_SESSION['user']=$_POST['matricule'] ;
                                     //il va étre dirigé au index.php
                                     echo "<script>window.location.href='index2.php'</script>";
                                     echo 9;
                                 } else {
                                     $req="select * from administrateur where matricule='" . $_POST['matricule']. "' and code='".substr(md5($code),0,10)."'; ";
                                     $res=mysqli_query($conn,$req);
                                     if (mysqli_num_rows($res)!=0) {
                                        $_SESSION['user']=$_POST['matricule'] ;
                                         header("location:index1.php");
                                         
                                         //lahi ywejeh chor index.php
                                     }
                                     echo  '<p class=\'ereur\'><b>VERIFIER LE MATRICULE OU LE MOT DE PASSE </b></p>';
                               
                             }
                         }
                         }
                   ?>