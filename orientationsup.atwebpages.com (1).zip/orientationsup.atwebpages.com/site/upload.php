<?php
//ini_set("display_errors", "1");
//error_reporting(E_ALL);
?>
<!DOCTYPE html>
<html>
<head>

</head>
<body>

<?php
if(isset($_FILES['excel']['name'])){
	$con=mysqli_connect('fdb33.awardspace.net','4146023_sup','Orientation123','4146023_sup');
	include "xlsx.php";
	if($con){
		$excel=SimpleXLSX::parse($_FILES['excel']['tmp_name']);
		//table x
        //variable x
        //$nom=$_SESSION["x"];
		$nom="CPEG";
        $k=0;
        $l=["Filiere","code","capacite","pays"];
		foreach ($excel->rows() as $key => $row) {
            if($k==0){
                for($j=1;$j<count($row)-1;$j++){
                    array_push($l,$row[$j]);
                }
            }
            $k+=1;
    
		}
        $q="";
        foreach($l as $f){
            $q.=$f. " varchar(50),";
			
        }
		$d="id int NOT NULL AUTO_INCREMENT primary key, ";
		$q = $d . $q;
		$d="DROP TABLE IF EXISTS ".$nom.";";
		mysqli_query($con,$d);
		$query="CREATE table ".$nom." (".rtrim($q,",").");";
        mysqli_query($con,$query);
        //notes
        $nom="note";
        $i=0;

		foreach ($excel->rows() as $key => $row) {
			$q="";
			foreach ($row as $key => $cell) {
				if($i==0){
					$q.=$cell. " varchar(50),";
					
				}else{
					$q.="'".$cell. "',";
				}
			}
	
			if($i==0){
		
				$d="DROP TABLE IF EXISTS ".$nom.";";
				mysqli_query($con,$d);
				$query="CREATE table ".$nom." (".rtrim($q,",").");";
				
			}
            else{
				$query="INSERT INTO ".$nom." values(".rtrim($q,",").");";
    
			}
            mysqli_query($con,$query);
			$i++;
        }
            //choix
		    //choix
			$nom="choix";
			$i=0;
			$l=[];
			foreach ($excel->rows() as $key => $row){
				array_push($l,$row[0]);
				$i++;
			}
			$len=count($l);
			$d="DROP TABLE IF EXISTS ".$nom.";";
			mysqli_query($con,$d);
			$q="create table ".$nom." ($l[0] varchar (50));";
			mysqli_query($con,$q);
			$k=0;
			foreach ($l as $e){
			
				if($k!=0){
				$qu="insert into ".$nom." values($e);";
				mysqli_query($con,$qu);
				
		}
		$k+=1;
		}
		$nom="moyenne_orientation";
			$i=0;
			$l=[];
			foreach ($excel->rows() as $key => $row){
				array_push($l,$row[0]);
				$i++;
			}
			$len=count($l);
			$d="DROP TABLE IF EXISTS ".$nom.";";
			mysqli_query($con,$d);
			$q="create table ".$nom." ($l[0] varchar (50));";
			mysqli_query($con,$q);
			$k=0;
			foreach ($l as $e){
	
				if($k!=0){
				$qu="insert into ".$nom." values($e);";
				mysqli_query($con,$qu);
				
		}
		$k+=1;
		}
    }
        
		}
		
    
