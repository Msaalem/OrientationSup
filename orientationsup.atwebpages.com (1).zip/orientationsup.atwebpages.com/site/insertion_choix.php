<?php
include '../filiere/conect.php';
session_start();

error_reporting(0);
ini_set('display_errors', 0);
$fl=$_SESSION['x'];
if(!empty($_SESSION['user']))$matricule=$_SESSION['user'];else  header("location:login.php");

?>
<!DOCTYPE html>
<html class="wide wow-animation" lang="en">
  <head>
    <title>#login</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="icon" href="images/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Montserrat:300,400,700%7CPoppins:300,400,500,700,900">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/fonts.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/login.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <style>.ie-panel{display: none;background: #212121;padding: 10px 0;box-shadow: 3px 3px 5px 0 rgba(0,0,0,.3);clear: both;text-align:center;position: relative;z-index: 1;} html.ie-10 .ie-panel, html.lt-ie-10 .ie-panel {display: block;}</style>
  </head>
  <body>
    <div class="ie-panel"><a href="http://windows.microsoft.com/en-US/internet-explorer/"><img src="images/ie8-panel/warning_bar_0000_us.jpg" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today."></a></div>
    <div class="preloader">
      <div class="preloader-body">
        <div class="cssload-container">
          <div class="cssload-speeding-wheel"></div>
        </div>
        <p>Loading...</p>
      </div>
    </div>
    <div class="page">
      <header class="section page-header">
        <!--RD Navbar-->
        <div class="rd-navbar-wrap">
          <nav class="rd-navbar rd-navbar-classic" data-layout="rd-navbar-fixed" data-sm-layout="rd-navbar-fixed" data-md-layout="rd-navbar-fixed" data-md-device-layout="rd-navbar-fixed" data-lg-layout="rd-navbar-static" data-lg-device-layout="rd-navbar-static" data-xl-layout="rd-navbar-static" data-xl-device-layout="rd-navbar-static" data-lg-stick-up-offset="46px" data-xl-stick-up-offset="46px" data-xxl-stick-up-offset="46px" data-lg-stick-up="true" data-xl-stick-up="true" data-xxl-stick-up="true">
            <div class="rd-navbar-collapse-toggle rd-navbar-fixed-element-1" data-rd-navbar-toggle=".rd-navbar-collapse"><span></span></div>
            <div class="rd-navbar-aside-outer rd-navbar-collapse bg-gray-dark">
              <div class="rd-navbar-aside">
              
              </div>
            </div>
            <div class="rd-navbar-main-outer">
              <div class="rd-navbar-main">
                <!--RD Navbar Panel-->
                <div class="rd-navbar-panel">
                  <!--RD Navbar Toggle-->
                  <button class="rd-navbar-toggle" data-rd-navbar-toggle=".rd-navbar-nav-wrap"><span></span></button>
                  <!--RD Navbar Brand-->
                  <div class="rd-navbar-brand">
                    <!--Brand--><a class="brand" href="../index.php"><img class="brand-logo-dark" src="images/logo-default-200x34.png" alt="" width="100" height="17"/><img class="brand-logo-light" src="images/logo-inverse-200x34.png" alt="" width="100" height="17"/></a>
                  </div>
                </div>
                <div class="rd-navbar-main-element">
                  <div class="rd-navbar-nav-wrap">
                    <ul class="rd-navbar-nav">
                      <li class="rd-nav-item"><a class="rd-nav-link" href="index2.php">Home</a>
                      </li>
                      <li class="rd-nav-item"><a class="rd-nav-link" href="../index.php">Log out<output></output></a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </nav>
        </div>
      </header>
    
      <section class="section section-intro context-dark">
        <div class="intro-bg" style="background: url() no-repeat;background-size:cover;background-position: top center;"></div>
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-xl-8 text-center">
              <h3 class="font-weight-bold wow fadeInLeft">Insertion de choix</h3>
              <p class="intro-description wow fadeInRight"></p>
            </div>
          </div>
        </div>
      </section>
       


    <!-- ===== Iconscout CSS ===== -->
   

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
  
    <style>
        .inp {
            width:50px;
        }
        .td{
            height:80px;
            
        }
        button{
            position: relative;
            left:40%;
        }
        main{
            margin: 50px 0;
          
    
    background: #fff;
    border-radius: 3px;
    box-shadow: 0 5px 10px rgba(0, 0, 0, 0.4);
    margin: 20px 20px;
    padding: 30px;
}
        
    </style>
</head>
<body>
<main>
<div class="container">
    
        
        <?php
        function m7i($s)
        {
          $n="";
          for($i=5;$i<strlen($s);$i++)$n=$n.$s[$i];
          return $n;
        }
          
$sql = "SHOW TABLES WHERE Tables_in_projet=\"resultat_$fl\";";
$r=mysqli_query($connection , $sql);
$sql=mysqli_fetch_assoc($r);
$titi=$_SESSION["user"];
if($sql){
  $req="select choix from resultat_$fl where matricule=\"$titi\"";
  $rr=mysqli_query($connection , $req);
  $ll=mysqli_fetch_assoc($rr);
  if(!empty($ll["choix"]))
  {
    echo "bienvenue $titi vous avez éte orienter vers   ".$ll["choix"];
  }else{
    echo "bienvenue $titi vous avez pas éte orienter";
  }
    
}else{
    

            echo '<h4>choisiser votre specialite</h4>
            <form action="insertion_choix.php"method="post">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">diplome</th>
                        <th scope="col">specialite</th>
                        <th scope="col">pays</th>
                        <th scope="col">choix/اختيار</th>
                    </tr>
                </thead>
                <tbody>';
            $getTd="SELECT * FROM  $fl";
            $s="SELECT * FROM `choix_$fl` WHERE matricule=$matricule";
            if($sql1 = mysqli_query($connection , $s)){
                $row1 = mysqli_fetch_assoc($sql1);
            }else{
                $row1=[];
            }
            $sql = mysqli_query($connection , $getTd);
            $countChoix=0;
            $i=0;
            $tfiliere=[];
            while($row = mysqli_fetch_assoc($sql)){
                $filiere=$row['code'];
                if($row1)
                $key = array_search ($row['code'], $row1);else $key[5]="";
                $key=m7i($key);
                $pays=$row['pays'];
           
                echo "<tr><td></td><td>$filiere</td>";
                echo "<td>$pays</td>";
                echo "<td><input type=\"number\"  onchange=\"f()\" class='inp'  id=\"$i\" name=\"inp$i\"value='$key'></td></tr>";
                array_push( $tfiliere,$filiere);
               $i++;
            }
            // $countColumn='select column_name as p from information_schema.columns where table_name="choix"';
            // $countColumns= mysqli_query($connection , $countColumn);
            // $row = mysqli_fetch_assoc($countColumnS);
            // echo $row['p'];
            // if(($countChoix+1)!=$row['p'])echo 5;
            $tfiliere_length=count($tfiliere);
            if( isset($_POST['sb'])){
                
                $bool=true;
                $d=-1;
                $i=0;
                $choix=[];
                foreach($_POST as $key => $value){
                   
                    if(!empty($_POST[$key])){$d++;}
                    array_push($choix,$value);
                }
               
               
                if($d<$tfiliere_length){echo "<p><b>inserez dans tous les champs</b></p>";$bool=false;}
                else{$bool=true;}
                $sortfiliers=[];
                for($i=1;$i<=count($tfiliere);$i++){
                   for($j=0;$j<count($tfiliere);$j++){
                       if($choix[$j]==$i)
                        { 
                              array_push($sortfiliers,$tfiliere[$j]);
                        }
                       
                   }
               }
              
                for($i=0;$i<count($sortfiliers)-1;$i++){$sortfiliers[$i]=preg_replace("~'~","\'",$sortfiliers[$i]);}

              
            
               
              
                $req0="select * from choix_$fl ";
               $res=mysqli_query($connection,$req0);
               $row=mysqli_fetch_row($res);
               $table_length=count($row)-1;
               
             
              
              
              $j=1;
              if($bool){
              foreach($sortfiliers as $i){
                $a='choix'.$j;
                
               $req2="update choix_$fl set $a='$i' where matricule='$matricule';";
           
               if (!$connection->query($req2)) {
                echo "query failed: (" . $connection->errno . ") " . $connection->error;
                }
               $res1=mysqli_query($connection,$req2);
               $j++;
                if($j> $table_length){break;}
            
            }
            echo "<script>window.location.href='fin_choix.php'</script>";
        }
        }
            
      
        
        
        echo "
        </tbody>
    </table>
    <input type=\"submit\" class=\"btn btn-primary\" name=\"sb\"></input>
    
    </form>
</div>  
    </main>
    <script src=\"script.js\"></script>";
      }
?>

<!--Footer-->

</div>
<div class="snackbars" id="form-output-global"></div>
<script src="js/core.min.js"></script>
<script src="js/script.js"></script>
</body>
</html>
    <script>
        // alert("nbchoix");
        function f() {
           
            d=[];
            tfiliere_length="<?php print($tfiliere_length) ;?>";
            for(let j=0;j<tfiliere_length;j++){d.push(j);}
            
            for(let x of d)
            {
                if(parseInt(document.getElementById(x).value)>8)
                {
                    alert("entrer un neaveau nombre entre 1 et "+tfiliere_length);
                
                    document.getElementById(x).value="";
                    
                }
                for (let j of d)
                        {
                            if(x != j)
                            {
                                if(document.getElementById(x).value==document.getElementById(j).value)
                                {
                                    document.getElementById(j).value="";
                                    
                                    
                                }
                            }
                        }
          
               
            }
           
        }
        
           
    </script>
</body>
</html>