<html lang="en">

<head>

     <title>SupNum</title>

   
     
     <style>
          img{
       width: 12em;
       height: 4em;
    } 
        body
          {
               height: 100%;
          }
          .btn{
               background-color: blue;
               border:none;
               width: 120px;
               height:50px;
               color:white;
               border-radius: 5px;
               font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
          }
       
          * {
 margin: 0;
 padding: 0;
 box-sizing: border-box;

}
.navbar {
 display: flex;
 align-items: center;
 justify-content: space-between;
 padding: 10px;
 background-color: rgb(32, 25, 25);
 color: #fff;
 margin-top: 0%;
}
.nav-links a {
     position: relative;
    font-family: "Poppins", sans-serif;
    display: inline-block;
    padding-bottom: 10px;
    color: #ffffff;
    font-size: 14px;
    line-height: 1.2;
    transition: .25s;
    text-transform: uppercase;
  font-style: normal;
  font-family: "Poppins", sans-serif;
}
/* LOGO */
.logo {
 font-size: 32px;
}
/* NAVBAR MENU */
.menu {
 display: flex;
 gap: 1em;
 font-size: 18px;
}
.menu li:hover {
 /* background-color: #4c9e9e; */
 /* border-radius: 5px;
 transition: 0.3s ease; */
 border-bottom: 2px solid white;
}
.menu li {
 padding: 5px 14px;
}
/* DROPDOWN MENU */
.services {
 position: relative; 
}
.dropdown {
 background-color: rgb(1, 139, 139);
 padding: 1em 0;
 position: absolute; /*WITH RESPECT TO PARENT*/
 display: none;
 border-radius: 8px;
 top: 35px;
}
.dropdown li + li {
 margin-top: 10px;
}
.dropdown li {
 padding: 0.5em 1em;
 width: 8em;
 text-align: center;
}
.dropdown li:hover {
 border-bottom: 2px solid white;
}
.services:hover .dropdown {
 display: block;
}

a {
 text-decoration: none;
}
li {
 list-style: none;
}

h3{
     font-family:arial;
}




          .grid{
            display: grid;
            place-items:  center;
            
        }
          
.img{
     width:550px;
     height:300px;
     border-radius:8px;
}
.fin{
     font-size:25px;
}
     </style>


</head>

<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">
<nav class="navbar">
     <!-- LOGO -->
          <div class="rd-navbar-brand">
                    <!--Brand--><a class="brand" href="../index.php"><img class="" src="images/logo-default-200x34.png" alt="" width="100" height="20"/> </a>
                  </div></div>
     <!-- NAVIGATION MENU -->
     <ul class="nav-links">
       <!-- USING CHECKBOX HACK -->
       <!-- NAVIGATION MENUS -->
       <div class="menu">
       <li><a href="../site/index1.php">Home</a></li>
         <li><a href="../filiere/parametrage.php">Orientation</a></li>
       </div>
     </ul>
   </nav> </div>
     
     
<br><br>
     
     <section class="grid" >
          <h3 style="font-family: arial;">
            Veuillez Importer le fichier excel en respectant la structure suivante : <br>
            1)le premier colonne doit contient le matricule de l'étudiant. <br>
            2)ensuite les autres colonnes doivent contiennent les noms des matières  <br>		
            3)en fin une colonne qui contient la moyenne générale de l'étudiant <br>
              vous trouvez ci-dessous un exemple de fichier note. <br>
          </h3>
          <img class="img" src="e.jpeg" alt="">
          <h2>
            <div class="container">
                <h1>Importer</h1>
            
            
                <form method="POST" action="" enctype="multipart/form-data">

                           
                <div class="form-group">          
                        <input type="file" name="excel" class="form-control" required>
                    </div>
                    <?php
                    error_reporting(0);
                    ini_set('display_errors', 0);
                     $con=mysqli_connect('fdb33.awardspace.net','4146023_sup','Orientation123','4146023_sup');
                    if(isset($_POST["sb"]))
                    {
                         session_start();
                        
                         ###################################################################
                         if(isset($_FILES['excel']['name'])){
                             
                              include "xlsx.php";
                              if($con){
                                   $excel=SimpleXLSX::parse($_FILES['excel']['tmp_name']);
                                 $fl=$_SESSION['x'];
                                
                                 $nom="note_$fl";
                                 $i=0;
                         
                                   foreach ($excel->rows() as $key => $row) {
                                        $q="";
                                        foreach ($row as $key => $cell) {
                                             if($i==0){
                                                  $q.=$cell. " varchar(50),";
                                                  
                                             }else{
                                                  $q.="'".$cell. "',";
                                             }
                                        }
                              
                                        if($i==0){
                                   
                                             $d="DROP TABLE IF EXISTS ".$nom.";";
                                             mysqli_query($con,$d);
                                             $query="CREATE table ".$nom." (".rtrim($q,",").");";
                                           
                                             
                                        }
                                     else{
                                             $query="INSERT INTO ".$nom." values(".rtrim($q,",").");";
                                         
                             
                                        }
                                     mysqli_query($con,$query);
                                        $i++;
                                 }
                                  
                             }
                                 
                          
                            
                             }
                             $fl=$_SESSION['x'];
                             $req="delete from choix_$fl";
                             $req1="insert into choix_$fl(matricule) select matricule from note_$fl";
                             mysqli_query($con,$req);
                             mysqli_query($con,$req1);
                             echo "<script >window.location.href='../filiere/moyenne_orientation_2.php';</script>";
                                   }
                                   
                             
                         
                         ###################################################################
                        
                     
                    
                    ?>
                         <button style="position:absolute; bottom: -20px;right: 4px;"class="btn" name="sb"><p class='fin'>FIN</p></button>

                    <!-- <div class="form-group">
                        <button type="submit" name="Submit" class="btn btn-success">Upload</button>
                    </div> -->
            
                </form>
            </div>
        </h2>
          
          
     </section>
     

     <!-- SCRIPTS -->
     <script src="../js/jquery.js"></script>
     <script src="../js/bootstrap.min.js"></script>

</body>

</html>
