<!DOCTYPE html>
<html>

<head>

    <title>propros</title>
    <link rel="stylesheet" href="css/propos.css">
    <link rel="icon" href="images/logo.png">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/style.css">



</head>

<body>
    <!-- MENU -->
    <section class="navbar custom-navbar navbar-fixed-top" role="navigation">
        <div class="container">

            <div class="navbar-header">
                <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon icon-bar"></span>
                    <span class="icon icon-bar"></span>
                    <span class="icon icon-bar"></span>
                </button>

                <!-- lOGO TEXT -->

                <a href="../index.php" class="navbar-brand">Orientation</a>
            </div>

            <!-- MENU LINKS -->


            <div class="collapse navbar-collapse">
                <ul class="nav navbar-nav navbar-nav-first">
                    <li><a href="../index.php" class="smoothScroll">Home</a></li>
                    <li><a href="orienter.php" class="smoothScroll">orienter</a></li>
                </ul>



            </div>

        </div>
    </section>







    <div class="header">
        <div class="main">
            <h1>A propos de SupNum</h1>
            <p>
                <i>
                    <br>
                    La formation de SupNum est celle d’une licence professionnalisante
                    qui s’inspire du Bachelor Engineering de l’enseignement supérieur anglosaxon.
                    </br>

                    <br>
                    Son parcours de formation permet le développement des
                    compétences nécessaires à l’exercice des métiers du domaine du numérique,
                    ainsi que le développement des
                    compétences transversales d’autonomie, de sens de responsabilité et de travail en équipe.
                    </br>

                    <br>
                    La formation professionnalisante du SupNum adopte une approche de pédagogie active où les
                    étudiants
                    sont
                    acteurs de leur formation.
                    Les cours magistraux ne représentent que 26 % du volume des enseignements.
                    </br>

                    <br>
                    Les travaux dirigés et les travaux pratiques sont renforcés.

                    Les étudiants sont mobilisés dans plusieurs projets.

                    Une immersion professionnelle de 28 semaines de stages est prévue sur les 3 années de
                    formation.
                    </br>

                </i>
            </p>
        </div>
    </div>


    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/custom.js"></script>
</body>

</html>